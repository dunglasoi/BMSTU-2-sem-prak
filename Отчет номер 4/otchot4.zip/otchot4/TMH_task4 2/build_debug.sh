#!/bin/bash

gcc -c task_1.c
gcc task_1.o -o app.exe -lm
