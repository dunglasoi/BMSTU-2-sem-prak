#!/bin/bash

#declare -a sizes=("1000" "5000" "10000")
declare -a sizes=("500" "1000" "1500" "2000" "2500" "3000" "3500" "4000" "4500" "5000" \
    "5500" "6000" "6500" "7000" "7500" "8000" "8500" "9000" "9500" "10000")
declare -a opts=("O0" "O2" "Os")
declare -a init_array=("0" "1")
declare -a init_array_desc=("sorted" "random")
declare -a access_array=("0" "1" "2")
# fun_a, fun_b, fun_c
declare -a access_array_desc=("a" "b" "c")

mkdir -p ./data

for init in "${init_array[@]}"; do
    for opt in "${opts[@]}"; do
        for access in "${access_array[@]}"; do
            for size in "${sizes[@]}"; do
                printf "%s-%s-%s-%s \r" "${init_array_desc[$init]}" "$opt" "${access_array_desc[$access]}" "$size"
                ./apps/app_"${init_array_desc[$init]}"_"$opt"_"${access_array_desc[$access]}"_"$size".exe >> ./data/data_"${init_array_desc[$init]}"_"$opt"_"${access_array_desc[$access]}"_"$size".txt
                
                if [ $? -eq 0 ]; then
                    echo "Execution successful for ${init_array_desc[$init]}, $opt, ${access_array_desc[$access]}, $size"
                    
                    output=$(cat ./data/data_"${init_array_desc[$init]}"_"$opt"_"${access_array_desc[$access]}"_"$size".txt)
                    
                    if [ "$output" -eq 0 ]; then
                        echo "Output is correct for ${init_array_desc[$init]}, $opt, ${access_array_desc[$access]}, $size"
                    else
                        echo "Output is incorrect for ${init_array_desc[$init]}, $opt, ${access_array_desc[$access]}, $size"
                    fi
                else
                    echo "Execution failed for ${init_array_desc[$init]}, $opt, ${access_array_desc[$access]}, $size"
                fi
            done
        done
    done
done
