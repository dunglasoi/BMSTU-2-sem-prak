#!/usr/bin/bash

#declare -a sizes=("1000" "5000" "10000")
declare -a sizes=("500" "1000" "1500" "2000" "2500" "3000" "3500" "4000" "4500" "5000" \
    "5500" "6000" "6500" "7000" "7500" "8000" "8500" "9000" "9500" "10000")
declare -a opts=("O0" "O2" "Os")
declare -a init_array=("sorted" "random")
# fun_a, fun_b, fun_c
declare -a access_array=("a" "b" "c")

mkdir -p ./apps

for init in "${!init_array[@]}"; do
    for opt in "${opts[@]}"; do
        for access in "${!access_array[@]}"; do
            for i in "${sizes[@]}"; do
                printf "%s-%s-%s-%s\r" "${init_array[$init]}" "$opt" "${access_array[$access]}" "$i"
                gcc -std=c99 -Wall -Werror -Wextra -Wpedantic \
                    "-$opt" \
                    "-DNMAX=$i" \
                    "-DINIT=$init" \
                    "-DACCESS=$access" \
                    task_2.c -o "./apps/app_${init_array[$init]}_${opt}_${access_array[$access]}_$i.exe"
                
                if [ $? -eq 0 ]; then
                    echo "Compilation successful for ${init_array[$init]}, $opt, ${access_array[$access]}, $i"
                    if [ -f "./apps/app_${init_array[$init]}_${opt}_${access_array[$access]}_$i.exe" ]; then
                        echo "Executable file exists. Running the program..."
                        ./apps/app_${init_array[$init]}_${opt}_${access_array[$access]}_$i.exe
                    else
                        echo "Executable file does not exist."
                    fi
                else
                    echo "Compilation failed for ${init_array[$init]}, $opt, ${access_array[$access]}, $i"
                fi
            done
        done
    done
done
