#define _POSIX_C_SOURCE 199309L

#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#ifndef NMAX
#error Where is my NMAX
#endif

// методы sorted и random
#if INIT == 0
#define INIT_ARRAY init_sorted
#elif INIT == 1
#define INIT_ARRAY init_random
#else
#error Where is my method
#endif

// {a, b, c}
#if ACCESS == 0
#define ACCESS_ARRAY function_a
#elif ACCESS == 1
#define ACCESS_ARRAY function_b
#elif ACCESS == 2
#define ACCESS_ARRAY function_c
#else
#error where is my array method
#endif

typedef int array_t[NMAX];
array_t arr;
int len = NMAX;

unsigned long long microsecond_now(void)
{
    struct timespec val;

    if (clock_gettime(CLOCK_REALTIME, &val))
    {
        return (unsigned long long)-1;
    }
    // microsecond
    return val.tv_sec * 1000000ULL + val.tv_nsec / 1000ULL;
}

int function_a(int key, int *a, size_t *n)
{
    size_t i, j;

    // Поиск места для вставки ключа
    for (i = 0; i < *n && a[i] < key; i++)
    {
    }

    // Вставка ключа в отсортированный массив
    for (j = *n; j > i; j--)
    {
        a[j] = a[j - 1];
    }
    a[i] = key;
    (*n)++;

    return i; // Возвращает индекс вставленного элемента
}

int function_b(int key, int *a, size_t *n)
{
    size_t i, j;

    // Поиск места для вставки ключа
    for (i = 0; i < *n && *(a + i) < key; i++)
    {
    }

    // Вставка ключа в отсортированный массив
    for (j = *n; j > i; j--)
    {
        *(a + j) = *(a + j - 1);
    }
    *(a + i) = key;
    (*n)++;

    return i; // Возвращает индекс вставленного элемента
}

int function_c(int key, int *a, size_t *n)
{
    int *pbeg = a;
    int *pend = a + (*n);
    int *p;

    // Поиск места для вставки ключа
    for (p = pbeg; p < pend && *p < key; p++)
    {
    }

    // Вставка ключа в отсортированный массив
    for (int *q = pend; q > p; q--)
    {
        *q = *(q - 1);
    }
    *p = key;
    (*n)++;

    return p - pbeg; // Возвращает индекс вставленного элемента
}

// Сортировка вставками
int insertion_sort(int *a, size_t n)
{
    for (size_t i = 1; i < n; i++)
    {
        ACCESS_ARRAY(a[i], a, &i);
    }
    return 0;
}

void init_sorted(int *arr, int n)
{
    for (int i = 0; i < n; i++)
    {
        *(arr + i) = i;
    }
}

void init_random(int *arr, int n)
{
    srand(time(NULL));

    for (int i = 0; i < n; i++)
    {
        arr[i] = rand() % 1000;
    }
}

int main(void)
{
    assert(len > 1);

    INIT_ARRAY(arr, len);

    unsigned long long beg, end;

    // microsecond_now
    beg = microsecond_now();
    insertion_sort(arr, len);
    end = microsecond_now();

    printf("%llu\n", end - beg);


    return 0;
}