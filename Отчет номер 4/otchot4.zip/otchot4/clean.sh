#!/usr/bin/bash

rm -rf ./apps ./data ./preproc_data ./postproc_data ./graph
rm -rf *.o
rm -rf *.exe
rm -rk *.out