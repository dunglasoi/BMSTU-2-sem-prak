#!/usr/bin/bash

rm -rf ./graph/
mkdir -p ./graph

if [ -d ./graph ]; then
    python3 plot_liner1.py &
    python3 plot_liner2.py &
    python3 plot_errorbar.py &
    python3 plot_moustache.py &
    echo "success."
fi
