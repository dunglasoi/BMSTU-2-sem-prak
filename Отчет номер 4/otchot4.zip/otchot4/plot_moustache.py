import matplotlib.pyplot as plt
import os
import numpy as np
if __name__ == "__main__":
    fig, ax = plt.subplots()

    file_prefix = "data_a_O2_"
    data_dir = "./postproc_data/"

    colors = plt.cm.tab20(np.linspace(0, 1, 20))
    markers = ['o', 'x', '*', '+', 's', 'd', 'v', '^', '>', '<', 'p', 'h']


    for i, file in enumerate(os.listdir(data_dir)):
        if not file.startswith(file_prefix):
            continue

        # read data
        data = np.loadtxt(os.path.join(data_dir, file))

        # get x
        x = data[:, 0]

        # get y
        y = data[:, 1]
        y_max = y - data[:, 3]
        y_min = data[:, 2] - y
        quan_2 = data[:, 5]
        quan_1 = quan_2 - data[:, 4]
        quan_3 = data[:, 6] - quan_2

        color = colors[i % len(colors)]
        marker = markers[i % len(markers)]

        ax.errorbar(x, y, yerr=(y_min, y_max), color=color,
                    label=file, fmt=marker + '-', capsize=3, capthick=2)

        ax.errorbar(x, quan_2, yerr=(quan_1, quan_3), color=color,
                    label=None, fmt='x', capsize=2, capthick=3,
                    zorder=2.5, elinewidth=5, alpha=0.5)

    ax.set_xlabel("Количество элементов")
    ax.set_ylabel("Время")
    ax.set_title("График с усами")
    ax.legend()
    ax.grid(True)
    plt.savefig("./graph/moustache.svg")
    plt.show()
