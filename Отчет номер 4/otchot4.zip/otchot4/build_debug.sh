#!/bin/bash

gcc -c task_01.c
gcc task_01.o -o app.exe -lm
