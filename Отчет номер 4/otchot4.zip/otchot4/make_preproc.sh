#!/usr/bin/bash

declare -a sizes=("1000" "5000" "10000")
#declare -a sizes=("500" "1000" "1500" "2000" "2500" "3000" "3500" "4000" "4500" "5000" \
    "5500" "6000" "6500" "7000" "7500" "8000" "8500" "9000" "9500" "10000")
declare -a opts=("O0" "O2")
declare -a opts_desc=("O0" "O2")
declare -a init_array=("0" "1")
declare -a init_array_desc=("sorted" "random")
declare -a access_array=("0" "1" "2")
# fun_a, fun_b, fun_c
declare -a access_array_desc=("a" "b" "c")

rm -rf ./preproc_data/
mkdir -p ./preproc_data

for file in ./data/*; do
    python3 preprocessing.py "$file" "./preproc_data/$(basename "$file")"
done

rm -rf ./postproc_data/
mkdir -p ./postproc_data

# PLOT_LINEAR 1
for size in "${sizes[@]}"; do
    for access in "${access_array[@]}"; do
        for opt in "${opts[@]}"; do
            if [[ $access == "0" ]]; then
                filename="./postproc_data/data_${init_array_desc[0]}_${opt}_${access_array_desc[$access]}.txt"
                echo "$size $(cat ./preproc_data/data_${init_array_desc[0]}_${opt}_${access_array_desc[$access]}_${size}.txt)" >> "$filename"
            elif [[ $access == "1" ]]; then
                filename="./postproc_data/data_${init_array_desc[0]}_${opt}_${access_array_desc[$access]}_special.txt"
                echo "$size $(cat ./preproc_data/data_${init_array_desc[0]}_${opt}_${access_array_desc[$access]}_${size}.txt)" >> "$filename"
            else
                filename="./postproc_data/data_${init_array_desc[0]}_${opt}_${access_array_desc[$access]}.txt"
                echo "$size $(cat ./preproc_data/data_${init_array_desc[0]}_${opt}_${access_array_desc[$access]}_${size}.txt)" >> "$filename"
            fi
        done
    done
done

# PLOT_LINEA_2
for size in "${sizes[@]}"; do
    for access in "${access_array[@]}"; do
        for opt in "${opts[@]}"; do
            if [[ $access == "1" ]]; then
                filename="./postproc_data/data_${init_array_desc[1]}_${opt}_${access_array_desc[$access]}.txt"
                echo "$size $(cat ./preproc_data/data_${init_array_desc[1]}_${opt}_${access_array_desc[$access]}_${size}.txt)" >> "$filename"
            else
                filename="./postproc_data/data_${init_array_desc[1]}_${opt}_${access_array_desc[$access]}.txt"
                echo "$size $(cat ./preproc_data/data_${init_array_desc[1]}_${opt}_${access_array_desc[$access]}_${size}.txt)" >> "$filename"
            fi
        done
    done
done

# ERROR_PLOT
for size in "${sizes[@]}"; do
    for access in "${access_array[@]}"; do
        for init in "${init_array[@]}"; do
            if [[ $access == "2" && $init == "0" ]]; then
                filename="./postproc_data/data_${opts_desc[1]}_${init_array_desc[$init]}_${access_array_desc[$access]}_special.txt"
                echo "$size $(cat ./preproc_data/data_${init_array_desc[0]}_${opts[1]}_${access_array_desc[$access]}_${size}.txt)" >> "$filename"
            else
                filename="./postproc_data/data_${opts_desc[1]}_${init_array_desc[$init]}_${access_array_desc[$access]}.txt"
                echo "$size $(cat ./preproc_data/data_${init_array_desc[0]}_${opts[1]}_${access_array_desc[$access]}_${size}.txt)" >> "$filename"
            fi
        done
    done
done

# MOUSTACHE_PLOT
for size in "${sizes[@]}"; do
    for init in "${init_array[@]}"; do
        if [[ $init == "1" ]]; then
            filename="./postproc_data/data_${access_array_desc[0]}_${opts_desc[1]}_${init_array_desc[$init]}_special.txt"
            echo "$size $(cat ./preproc_data/data_${init_array_desc[0]}_${opts[1]}_${access_array_desc[0]}_${size}.txt)" >> "$filename"
        else
            filename="./postproc_data/data_${access_array_desc[0]}_${opts_desc[1]}_${init_array_desc[$init]}.txt"
            echo "$size $(cat ./preproc_data/data_${init_array_desc[0]}_${opts[1]}_${access_array_desc[0]}_${size}.txt)" >> "$filename"
        fi
    done
done


if [ -d ./postproc_data ]; then
    echo "Postprocessing completed successfully."
else
    echo "Postprocessing failed."
fi