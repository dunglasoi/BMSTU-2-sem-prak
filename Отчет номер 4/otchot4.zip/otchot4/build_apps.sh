#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <stdint.h>

#define NUM_RUNS 10

double timeit_nanosleep(long ns, int method)
{
    struct timespec req, rem;
    int i;
    double diff;
    struct timeval tv_start, tv_end;
    struct timespec ts_start, ts_end;
    uint64_t start, end;
    uint32_t c, d;

    req.tv_sec = ns / 1000000000;
    req.tv_nsec = ns % 1000000000;

    diff = 0.0;

    for (i = 0; i < NUM_RUNS; i++)
    {
        switch (method)
        {
        case 1:
            // Using gettimeofday
            gettimeofday(&tv_start, NULL);
            nanosleep(&req, &rem);
            gettimeofday(&tv_end, NULL);
            diff += (tv_end.tv_sec - tv_start.tv_sec) + (tv_end.tv_usec - tv_start.tv_usec) / 1000000.0;
            break;
        case 2:
            // Using clock_gettime with CLOCK_REALTIME
            clock_gettime(CLOCK_REALTIME, &ts_start);
            nanosleep(&req, &rem);
            clock_gettime(CLOCK_REALTIME, &ts_end);
            diff += (ts_end.tv_sec - ts_start.tv_sec) + (ts_end.tv_nsec - ts_start.tv_nsec) / 1000000000.0;
            break;
        case 3:
            // Using clock
            start = clock();
            nanosleep(&req, &rem);
            end = clock();
            diff += (end - start) / (double)CLOCKS_PER_SEC;
            break;
        case 4:
            // Using __builtin_readcyclecounter
            start = __builtin_readcyclecounter();
            nanosleep(&req, &rem);
            end = __builtin_readcyclecounter();
            diff += (end - start) / 1000000.0;
            break;
        default:
            printf("Invalid method!\n");
            exit(EXIT_FAILURE);
        }
    }

    return diff / NUM_RUNS;
}

void print_results(const char *method, long ns)
{
    printf("Results for %s:\n", method);
    printf("Time for 1s: %.6f sec\n", timeit_nanosleep(ns, 1));
    printf("Time for 100ms: %.6f sec\n", timeit_nanosleep(ns, 2));
    printf("Time for 50ms: %.6f sec\n", timeit_nanosleep(ns, 3));
    printf("Time for 10ms: %.6f sec\n", timeit_nanosleep(ns, 4));
    printf("\n");
}

int main()
{
    int i;
    long ns[] = {1000000000, 100000000, 50000000, 10000000};
    char *methods[] = {"gettimeofday", "clock_gettime", "clock", "__rdtsc"};
    int num_methods = 4;

    for (i = 0; i < num_methods; i++)
    {
        print_results(methods[i], ns[i]);

    }
    return 0;
}
