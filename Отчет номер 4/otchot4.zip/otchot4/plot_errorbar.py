import matplotlib.pyplot as plt
import os
import numpy as np

if __name__ == "__main__":
    fig, ax = plt.subplots()
    file_prefix = "data_O2_"
    data_dir = "./postproc_data/"

    colors = plt.cm.tab20(np.linspace(0, 1, 20))
    markers = ['o', 'x', '*', '+', 's', 'd', 'v', '^', '>', '<', 'p', 'h']

    for i, file in enumerate(os.listdir(data_dir)):
        if not file.startswith(file_prefix):
            continue

        # read data
        data = np.loadtxt(os.path.join(data_dir, file))

        # get x
        x = data[:, 0]

        # get y
        y = data[:, 1]
        y_min = data[:, 3]
        y_max = data[:, 2]
        y_err = np.array([y_max - y, y - y_min])

        marker = markers[i % len(markers)]

        ax.errorbar(x, y, yerr=y_err, label=f'{file}', marker=marker, capsize=3, capthick=3)

    ax.set_xlabel("Количество элементов")
    ax.set_ylabel("Время, s")
    ax.set_title("Кусочно-линейный график с ошибкой")
    ax.legend()
    ax.grid(True)
    plt.savefig("./graph/errorbar.svg")
    plt.show()
